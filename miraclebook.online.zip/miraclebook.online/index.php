<?php
include('config.php');
include ('fungsi.php');
?>
<!doctype html>
<html lang="<?php echo $lang; ?>">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $site_name.' - '.$site_desc; ?></title>
        <meta property="og:title" content="<?php echo $site_name.' - '.$site_desc; ?>">
        <?php include('css-searchbox.php'); ?>
        <?php include('css.php'); ?>
    </head>
    <body>
        <?php include('header.php'); ?>
         <!-- Banner -->       
        <center>
<a href="https://miraclebook.online/promo-lazada.php"><img alt="Promo Lazada Terbaru" src="https://miraclebook.online/img/promo-lazada-3.png" title="Promo Lazada Terbaru" /></a>
        </center>
 <!-- Banner -->  

        <div class="container">
            <ol xmlns:v="http://rdf.data-vocabulary.org/#" class="breadcrumb">
                <li typeof="v:Breadcrumb"><a rel="v:url" property="v:title" href="/">Home</a></li>
                <li><?php echo $site_desc; ?></li>
            </ol>
            <div class="clearfix" style="padding:15px 0">
                <?php
                $kws = home_kw(2);
                $kw = $kws[0];
                //$kw = 'coloring pages roadrunner';
                $images = ambil_gambar($kw);
                foreach($images as $i) {
                    echo "<div class=\"galeri col-md-4 col-sm-6\">";
                    echo "<a href=\"/".$single."/".sanitize_title2($i['judul'])."\">";
                    //echo "<a href=\"".$domain."/single.php?q=".urlencode($i['judul'])."\">";
                    echo "<div class=\"thumbnail\" style=\"background-image: url('".$i['thumb']."'); background-color: #cccccc; background-size: cover; background-repeat: no-repeat; background-position: center center;width:100%;height:180px;\"><noscript><img src=\"http://i0.wp.com/".str_replace(array('http://','https://'), '', $i['link'])."?quality=80&strip=all\"/></noscript></div>";
                    echo "<h3>".$i['judul']."</h3>\n";
                    echo "</a>";
                    echo "</div>";
                }
                ?>
            </div>
        </div>
        <?php include('footer.php'); ?>
        <?php include('histats.php'); ?>
    </body>
</html>