<?php
$ads = 'https://c.lazada.co.id/t/c.0HJV';
header( "refresh:1;url=$ads" );
?>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><?php echo $judul; ?></title>
    </head>
    <body>
        <center>
<title><?php echo $judul; ?></title>
<a href="<?php echo $ads; ?>"><img src="https://4.bp.blogspot.com/-bZUOc4SUa-k/XAvv_KqkiiI/AAAAAAAAAm0/0kvvlwqLFOwE-Te44dgrGPATdgRssz-RQCKgBGAs/s1600/loading.gif"></a></center>
    </body>
    <?php include('histats.php');?>
</html>