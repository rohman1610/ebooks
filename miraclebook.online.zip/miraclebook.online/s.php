<?php
function clean_uri($str) {
	$str = str_replace(array(" â€“ ", "â€™", "`", "Â´"), array(" - ", "'", "'", "'"), $str);
    $str = str_replace(array('[\', \']'), '', $str);
    $str = preg_replace('/\[.*\]/U', '', $str);
    $str = preg_replace('/&(amp;)?#?[a-z0-9]+;/i', '-', $str);
    $str = htmlentities($str, ENT_COMPAT, 'utf-8');
    $str = preg_replace('/&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);/i', '\\1', $str);
    $str = preg_replace(array('/[^a-z0-9]/i', '/[-]+/') , '-', $str);
	$str = strtolower(trim($str));
	$str = substr($str, 0, 70);
	$str = str_replace('-', ' ', $str);
	$str = preg_replace('/\s[\s]+/', ' ',$str);
	$str = str_replace(' ', '-', $str);
	$str = preg_replace('/^[\-]+/', '', $str);
	return preg_replace('/[\-]+$/', '', $str);
}

if (!empty($_POST['search'])) {
	$protocol = isset($_SERVER['HTTPS']) ? 'https' : 'http';
	@header("Location: " . $protocol . "://" . $_SERVER['HTTP_HOST'] . "/images/" . clean_uri($_POST['search']));
	exit();
}