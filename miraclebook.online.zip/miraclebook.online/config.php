<?php
error_reporting(0);
$domain			= 'https://miraclebook.online';
$domen			= $_SERVER['HTTP_HOST'];
$single 		= 'images';
$galeri 		= 'category';
$site_name		= 'images gallery';
$site_desc		= 'Find any picture! Here are image search engines and websites you can use to find nearly any image you might be looking for.';
$search_desc	= 'Find any picture! Here are image search engines and websites you can use to find nearly any image you might be looking for.';
$footer_name	= 'miraclebook.online';
$lang			= 'en-US';

$email 			= 'email[at]gmail.com';
?>