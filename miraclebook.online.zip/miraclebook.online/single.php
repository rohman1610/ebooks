<?php
header('HTTP/1.1 200 OK');
$domains = $_SERVER['HTTP_HOST'];
$permalinkx	=	$_SERVER['REQUEST_URI'];
$permalinky	=	explode('?',$permalinky);
$permalinky	=	$permalinky[0];
$permalink	=       explode('/',$permalinkx);
$permalinkz     =	$permalink[2];
$permalink	=	$permalink[2];
$permalink	=	explode('?',$permalink);
$permalink	=	$permalink[0];
$titlenya    	= 	str_replace(array('/','-','+','-'),' ',$permalink);
$titlenya      =       ucwords(str_replace('-', ' ', $titlenya));
$judul		=	$titlenya;
include('config.php');
include ('fungsi.php');
$q = $_GET['q'];
$keyword = bersih($q);
$cano = $domain.'/images/'.sanitize_title2($q);
$data = ambil_gambar($keyword);
$rating = number_format(rand( 50, 500));
?><!doctype html>
<html lang="<?php echo $lang; ?>">
    <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo $judul.' - '.$site_name; ?></title>
        <meta property="og:title" content="<?php echo $judul.' - '.$site_name; ?>">
        <meta property="og:description" content="Image Galleries for <?php echo $judul; ?>. Download all images of <?php echo $keyword; ?> for free at miraclebook.online<?php echo $domen; ?>">
        <meta name="description" content="Image Galleries for <?php echo $judul; ?>. Download all images of <?php echo $judul; ?> for free at <?php echo $domen; ?>">
        <link rel="canonical" href="<?php echo $cano; ?>" />
        <?php include('css-searchbox.php'); ?>
        <?php include('css.php'); ?>
    </head>
    <body>
        <?php include('header.php'); ?>
 <!-- Banner -->       
        <center>
<a href="https://miraclebook.online/promo-lazada.php"><img alt="Promo Lazada Terbaru" src="https://miraclebook.online/img/promo-lazada-3.png" title="Promo Lazada Terbaru" /></a>
        </center>
 <!-- Banner -->  
        <div class="container">
            <ol xmlns:v="http://rdf.data-vocabulary.org/#" class="breadcrumb">
                <li typeof="v:Breadcrumb"><a rel="v:url" property="v:title" href="/">Home</a></li>
                <li><?php echo $keyword; ?></li>
            </ol>
            <div class="ads">

            </div>
            <?php if(empty($data) || $data == false) {
                echo '<h1>Not Found</h1>';
            }
            else { ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="thumbnail" style="background-image: url('<?php echo $data[0]['thumb']; ?>'); background-color: #cccccc; background-size: cover; background-repeat: no-repeat; background-position: center center;width:100%;height:auto;min-height:300px">
                        <img src="<?php echo "http://i0.wp.com/".str_replace(array('http://','https://'), '', $data[0]['link'])."?quality=80&strip=all"; ?>" alt="<?php echo $keyword; ?>" title="<?php echo $keyword; ?>" />
                        <noscript><img src="<?php echo "http://i0.wp.com/".str_replace(array('http://','https://'), '', $data[0]['link'])."?quality=80&strip=all"; ?>" alt="<?php echo $keyword; ?>" title="<?php echo $keyword; ?>" /></noscript>
                    </div>
                    <div class="ads">
                     <!-- Banner -->
                        <center>
<a href="https://miraclebook.online/promo-lazada.php"><img alt="Promo Lazada Terbaru" height="56" src="https://miraclebook.online/img/promo-lazada.png" title="Promo Lazada Terbaru" width="610" /></a>
                       </center>
                     <!-- Banner -->
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info">
                    <h1 class="entry-title"><a href="<?php echo $cano; ?>" rel="bookmark"><?php echo $keyword; ?></a></h1>
                    <ul class="list-group">
                        <li class="list-group-item">Category : Images</li>
                        <li class="list-group-item">Post Date : <?php echo date('F j, Y') ?></li>
                        <li class="list-group-item text-center"><a class="btn btn-primary" href="<?php echo "http://i0.wp.com/".str_replace(array('http://','https://'), '', $data[0]['link'])."?quality=80&strip=all"; ?>">Download Image</a></li>
                    </ul>
                    </div>
                                        <hr>
                    <span style=color:#666;font-size:small><div itemscope itemtype=http://data-vocabulary.org/Review-aggregate><span itemprop=itemreviewed><?php echo $domains; ?></span> <img itemprop=photo src=""> <span itemprop=rating itemscope itemtype=http://data-vocabulary.org/Rating><span itemprop=average>9</span> out of <span itemprop=best>10</span></span> based on <span itemprop=votes><?php echo number_format(rand( 100, 1000)); ?></span> ratings. <span itemprop=count><?php echo number_format(rand( 1000, 5000)); ?></span> user reviews.</div></span>
                    <div class="relatedkey clearfix">
                    <h4>Related to <?php echo $keyword; ?></h4>
                    <?php
                    $suggest = related($keyword);
                    if(!empty($suggest)) {
                        foreach($suggest as $key) {
                            echo "<a class=\"label label-primary\" href=\"/".$single."/".sanitize_title($key)."\" title=\"".$key."\">".$key."</a>\n";
                            //echo "<a class=\"label label-primary\" href=\"single.php?q=".urlencode($key)."\" title=\"".$key."\">".$key."</a>\n";
                        }
                    }
                    $jml = number_format(rand( 5, 12));
                    $kws = home_kw($jml);
                    foreach($kws as $kw) {
                        echo "<a class=\"label label-primary\" href=\"/".$single."/".sanitize_title2($kw)."\" title=\"".$kw."\">$kw</a>\n";
                        //echo "<a class=\"label label-primary\" href=\"galeri.php?q=".urlencode($kw)."\" title=\"".$kw."\">$kw</a>\n";
                    } ?>
                    </div>
                </div>
            </div>

            <div class="striped text-center">
            <h2><?php echo $keyword; ?> Gallery</h2>
<br />
<?php
function limit_words($string, $word_limit)
{
$words = explode(" ",$string);
return implode(" ",array_splice($words,0,$word_limit));
}
?>

<?php
echo '';
  $firstx = ($nav - 1) * 10;
  $firstx = $firstx + 1; 
  $urlrss    = 'https://www.bing.com/search?q='.urlencode(limit_words($judul,6)).'&count=10&first='.$firstx.'&format=rss';
  $feedbing  = simplexml_load_string(BingText($urlrss));
   foreach ($feedbing->channel->item as $itembing):
       $titled	= $itembing->title;
       $tit	= $itembing->title;
$titled		= str_replace(array('www','/','-','+','-','%7C','jpg','php','gif','html','Blogspot','Com','.com','http','Wikipedia','Wikip�dia','YouTube','Amazon'),' ',$titled);
       $url = sanitize_title($titled);
       $desced	= $itembing->description;
$desced		= str_replace(array('www','/','-','+','-','%7C','jpg','php','gif','html','Blogspot','Com','.com','http','Wikipedia','Wikip�dia','YouTube','Amazon'),' ',$desced);
       $pubded	= $itembing->pubDate; 
  echo  '<strong>'.$titled.'</strong><br>'.$desced.'<br>';
endforeach;
	?>

            <div class="panel panel-default">
 <!-- Banner -->       
        <center>
<a href="https://miraclebook.online/promo-lazada.php"><img alt="Promo Lazada Terbaru" src="https://miraclebook.online/img/promo-lazada-2.jpg" title="Promo Lazada Terbaru" /></a>
        </center>
 <!-- Banner --> 
            </div>

            <div class="row"> 
            <?php
                if($data !== false) {
                    foreach($data as $i) {
                        echo "<div class=\"galeri col-xs-6 col-sm-4 col-md-3\">\n";
                        echo "<a title=\"".$i['judul']."\" href=\"http://i0.wp.com/".str_replace(array('http://','https://'), '', $i['link'])."?quality=80&strip=all\"><div class=\"thumbnail\" style=\"background-image: url('".$i['thumb']."'); background-color: #cccccc; background-size: cover; background-repeat: no-repeat; background-position: center center;width:160px;height:140px;\"><noscript><img src=\"".$i['link']."\" alt=\"".$i['judul']."\"/></noscript></div></a>\n";
                        echo "<h3>".$i['judul']."</h3>\n";
                        echo "<h3><a href=\"/".$single."/".sanitize_title2($i['judul'])."\" title=\"".$i['judul']."\">".$i['judul']."</a></h3>\n";
                        echo "</div>\n";
                    }
                }
            ?>
            </div>
            </div>
            <?php } ?>
        </div>
        <?php include('footer.php'); ?>
        <?php include('histats.php'); ?>
    </body>
</html>