
        <nav class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <a class="navbar-brand" href="/"><?php echo $site_name; ?></a>
                </div>
                            </div>
        </nav>
        
<?php include('search.php'); ?>
        <br>
        <div class="container">
            <div class="panel panel-default">
                <center>
<!-- Iklan Adsense disini -->
                </center>
            </div>
        </div>
